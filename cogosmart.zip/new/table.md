#date - 23-12-2025

table -  m_load - change add column - product
table - stock_in - new table added
table - stock_out - new table added
table - filter - new table added

